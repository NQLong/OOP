#include "../../Header/Actor/Librarian.h"
#include "../../Header/CatalogInterFace/Search.h"
#include "../../Header/CatalogInterFace/Manage.h"

Librarian::~Librarian() {}

void Librarian::view(Library *lib)
{
    int option;
    bool loop = true;
    Search* search;
    Manage* manage;
    while (loop)
    {
        int count = 1;
        clear();

        cout
            << setw(3) << left << to_string(count++) + "."
            << "Search Book." << endl
            << setw(3) << left << to_string(count++) + "."
            << "Manage Book." << endl
            << setw(3) << left << to_string(count++) + "."
            << "Modify your infmation ." << endl
            << setw(3) << left << to_string(count++) + "."
            << "Add user." << endl

            << endl
            << setw(3) << left << "0."
            << "Back." << endl;

        cout << endl
             << "Enter your choice: ";
        cin >> option;
        cin.ignore();
        switch (option)
        {
        case 1:
            clear();
            search = lib->get_cactalog();
            search->search_view();
            break;
        case 2:
            clear();
            manage = lib->get_cactalog();
            manage->manage_view();
            break;
        case 3:
            clear();
            this->modify_user_info();

            break;
        case 4:
            clear();
        default:
            loop = false;
            break;
        }
    }

    return;
}

//getter setter
string Librarian::getPosition()
{
    return this->position;
}

void Librarian::setPosition(string position)
{
    this->position = position;
}
