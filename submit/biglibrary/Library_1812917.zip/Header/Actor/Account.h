#ifndef B9580843_AB1C_4641_A53C_5C52BC90AA41
#define B9580843_AB1C_4641_A53C_5C52BC90AA41
#include "../Constraint/Constraint.h"

class Account
{
private:
    static int new_numb;
    int number;

public:
};

int Account::new_numb = 0;

#endif /* B9580843_AB1C_4641_A53C_5C52BC90AA41 */
