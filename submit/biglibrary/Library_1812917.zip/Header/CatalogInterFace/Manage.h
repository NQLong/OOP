#ifndef BBFAC183_E077_4910_9C05_E16AC903AAA9
#define BBFAC183_E077_4910_9C05_E16AC903AAA9

class Manage
{
public:
    virtual void manage_view() = 0;
    virtual void loan_book() = 0;
};

#endif /* BBFAC183_E077_4910_9C05_E16AC903AAA9 */
